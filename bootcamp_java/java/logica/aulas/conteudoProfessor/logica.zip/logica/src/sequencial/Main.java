package sequencial;

public class Main {

	public static void main(String[] args) {
		
		System.out.print("Seja bem-vindo(a) a TI Academy Brasil.\n");

	}

}
