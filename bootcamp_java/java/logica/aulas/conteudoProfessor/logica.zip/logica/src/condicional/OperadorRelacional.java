package condicional;

public class OperadorRelacional {

	public static void main(String[] args) {
		
		int x = 5;
		
		System.out.println(x == 5);
		System.out.println(x != 5);
		System.out.println(x > 10);
		System.out.println(x < 10);
		System.out.println(x >= 10);
		System.out.println(x <= 10);

	}

}
