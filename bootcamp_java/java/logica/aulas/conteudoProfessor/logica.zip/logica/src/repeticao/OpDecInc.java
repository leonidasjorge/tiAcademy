package repeticao;

public class OpDecInc {

	public static void main(String[] args) {
		int x = 5;
		System.out.println(x++);
		System.out.println(x);
		System.out.println(++x);
		System.out.println(x--);
		System.out.println(x);
		System.out.println(--x);
	}

}
