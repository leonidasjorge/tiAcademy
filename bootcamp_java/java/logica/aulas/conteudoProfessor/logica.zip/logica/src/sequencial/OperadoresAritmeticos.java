package sequencial;

public class OperadoresAritmeticos {

	public static void main(String[] args) {
		
		System.out.println(5 * 6 / 3);
		System.out.println(5 + 2 * 4);
		System.out.println((5 + 2) * 4);
		System.out.println(70 / (5 + 2) * 4);
		System.out.println(70 / ((5 + 2) * 4));
		System.out.println(18 / 4);
		System.out.println(18.0 / 4.0);
		System.out.println(18 % 4);

	}

}
