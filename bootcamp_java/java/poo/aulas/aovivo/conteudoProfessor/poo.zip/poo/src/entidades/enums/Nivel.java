package entidades.enums;

public enum Nivel {
	JUNIOR,
	PLENO,
	SENIOR;
}
