window.onload = function(){

//regitros 
let registros = [
    {
     'nome': 'Marcelo',
     'email': 'marcelo@gmail.com'
    },

    {
     'nome': 'Suelem',
     'email': 'suelem@gmail.com'
    },
]


}